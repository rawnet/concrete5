<?php
namespace Concrete\Controller\Dialog\Page;
use Area;
use Stack;
use Permissions;
use PageEditResponse;

class Clipboard extends \Concrete\Controller\Panel\Add {

	protected $viewPath = '/dialogs/page/clipboard';

}

